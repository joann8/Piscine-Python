# Joann Package

This is a simple package for Python Piscine @42